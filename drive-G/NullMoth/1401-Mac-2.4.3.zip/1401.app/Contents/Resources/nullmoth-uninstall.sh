#!/bin/bash
set -u
# This script runs as root and calls cp, rm, mv and kmutil by name. Without a
# fixed PATH those resolve through whatever the caller exported, and kmutil
# rebuilds the auxiliary kernel collection.
PATH=/usr/bin:/bin:/usr/sbin:/sbin; export PATH
# the NVIDIA driver only: the AMD/Intel GPU driver, the NPU driver and the audio driver are separate products with
# their own uninstallers
KEXTS="NVRM NVAccel NVRMFB NVRMAGDC"; EXT=/Library/Extensions; GB=/Library/GPUBundles
KC=/Library/KernelCollections/AuxiliaryKernelExtensions.kc
K=/System/Library/Kernels/kernel
KARG=(--allow-missing-kdk); [ -f "$K" ] && KARG+=(--kernel "$K")   # without a matching Kernel Debug Kit, kmutil needs --allow-missing-kdk
KB=/System/Library/KernelCollections/BootKernelExtensions.kc
KS=/System/Library/KernelCollections/SystemKernelExtensions.kc
REMOVING=0; RB=""; NEWKC=""; REMOVE_KC=0; CANDIDATE=""
rollback_removal() {
  local failed=0 k b
  for k in $KEXTS; do [ ! -e "$RB/$k.kext" ] || ditto "$RB/$k.kext" "$EXT/$k.kext" || failed=1; done
  for b in NVMTLDriver.bundle NVIDIAShared.bundle nvmtl nvmtl-allow.txt; do [ ! -e "$RB/$b" ] || ditto "$RB/$b" "$GB/$b" || failed=1; done
  [ ! -e "$RB/kexts" ] || ditto "$RB/kexts" /Library/NullMoth/kexts || failed=1
  [ ! -e "$RB/driver-version" ] || cp -p "$RB/driver-version" /Library/NullMoth/driver-version || failed=1
  [ ! -e "$RB/update-pending" ] || cp -p "$RB/update-pending" /Library/NullMoth/update-pending || failed=1
  [ ! -e "$RB/com.nullmoth.osupdate.plist" ] || cp -p "$RB/com.nullmoth.osupdate.plist" /Library/LaunchDaemons/ || failed=1
  if [ -e "$RB/AuxiliaryKernelExtensions.kc" ]; then cp -p "$RB/AuxiliaryKernelExtensions.kc" "$KC" || failed=1
  else rm -f "$KC" || failed=1; fi
  return "$failed"
}
die() {
  echo "STOP: $*" >&2
  if [ "$REMOVING" = 1 ]; then
    if rollback_removal; then echo "Previous driver files and collection restored." >&2
    else echo "Removal rollback incomplete; backup retained at $RB." >&2; exit 1; fi
  fi
  [ -z "$RB" ] || rm -rf "$RB"
  [ -z "$NEWKC" ] || rm -f "$NEWKC"
  exit 1
}
trap 'die "uninstaller interrupted (signal HUP)"' HUP
trap 'die "uninstaller interrupted (signal INT)"' INT
trap 'die "uninstaller interrupted (signal TERM)"' TERM
[ "$(id -u)" -eq 0 ] || die "run with sudo"
# SIP's filesystem protection makes the driver's files and the kernel collection read-only even for root: removal then
# failed half-way ("Operation not permitted" on every bundle, then kmutil). The driver cannot load in that state either,
# so stop before anything is touched and say how to get out of it.
SIPS=$(csrutil status 2>/dev/null)
if printf '%s\n' "$SIPS" | grep -q 'status: enabled\.' || printf '%s\n' "$SIPS" | grep -q 'Filesystem Protections: enabled'; then
  die "System Integrity Protection is on, so macOS will not let the driver be removed (and the driver cannot load while it is on). Restart once so OpenCore applies its SIP setting again, then remove the driver again. Nothing was changed."
fi
BK=${1:-}
[ -z "$BK" ] || [ -d "$BK" ] || die "no backup at $BK"
BUILD=$(sw_vers -buildVersion)
printf '%s\n' "$BUILD" | grep -Eq '^[0-9]+[A-Za-z][A-Za-z0-9]+$' || die "cannot identify the current macOS build"
# Rebuild from the current third-party repository. A same-build backup can
# still predate unrelated driver changes and is not a removal candidate.
left=$(find "$EXT" -maxdepth 1 -name '*.kext' 2>/dev/null | while read -r x; do
  n=$(basename "$x" .kext); if [[ " $KEXTS " == *" $n "* ]]; then continue; fi
  [ -d "$x/Contents/MacOS" ] && echo "$x"
  done | wc -l | tr -d ' ')
if [ "$left" = 0 ]; then
  REMOVE_KC=1
else
  RB=$(mktemp -d /var/tmp/nullmoth-remove.XXXX) && [ -n "$RB" ] || die "cannot create the removal preflight directory"
  mkdir -p "$RB/repo" || die "cannot create the removal repository"
  for x in "$EXT"/*.kext; do
    [ -d "$x" ] || continue
    n=$(basename "$x" .kext); if [[ " $KEXTS " == *" $n "* ]]; then continue; fi
    cp -Rp "$x" "$RB/repo/" || die "cannot stage $n for the removal collection"
  done
  NEWKC="$KC.nullmoth-remove-new"; rm -f "$NEWKC" || die "cannot clear the removal candidate"
  kmutil create -n aux --volume-root / ${KARG[@]+"${KARG[@]}"} -B $KB -S $KS --repository "$RB/repo" -A "$NEWKC" -z >/dev/null 2>&1 || die "kmutil could not rebuild the collection"
  [ -s "$NEWKC" ] || die "kmutil produced no removal collection"
  INS=$(kmutil inspect -a x86_64 -A "$NEWKC" 2>/dev/null) || die "cannot inspect the removal collection"
  printf '%s\n' "$INS" | grep -q com.nullmoth && die "the removal collection still lists the NVIDIA driver"
  # Other processes can move or delete files in /Library/KernelCollections between this check and the publish below.
  # A private copy of the verified collection lets the publish go ahead when the candidate there is gone.
  cp -p "$NEWKC" "$RB/removal-candidate.kc" || die "cannot keep a copy of the removal collection"
  CANDIDATE=$NEWKC
fi
# Finish all collection checks before changing installed files.
if [ -z "$RB" ]; then RB=$(mktemp -d /var/tmp/nullmoth-remove.XXXX) && [ -n "$RB" ] || die "cannot create the removal backup"; fi
for k in $KEXTS; do [ ! -e "$EXT/$k.kext" ] || ditto "$EXT/$k.kext" "$RB/$k.kext" || die "cannot back up $k"; done
for b in NVMTLDriver.bundle NVIDIAShared.bundle nvmtl nvmtl-allow.txt; do [ ! -e "$GB/$b" ] || ditto "$GB/$b" "$RB/$b" || die "cannot back up $b"; done
for f in /Library/NullMoth/kexts /Library/NullMoth/driver-version /Library/NullMoth/update-pending /Library/LaunchDaemons/com.nullmoth.osupdate.plist "$KC"; do
  [ ! -e "$f" ] || cp -Rp "$f" "$RB/" || die "cannot back up the removal state"
done
REMOVING=1
for k in $KEXTS; do rm -rf "$EXT/$k.kext" || die "cannot remove $k"; done
for b in NVMTLDriver.bundle NVIDIAShared.bundle nvmtl nvmtl-allow.txt; do rm -rf "$GB/$b" || die "cannot remove $b"; done
rm -rf /Library/NullMoth/kexts /Library/NullMoth/nvfw /Library/NullMoth/driver-version /Library/NullMoth/update-pending /Library/LaunchDaemons/com.nullmoth.osupdate.plist || die "cannot remove the cached driver or update switcher"
# the firmware used to live here; an install no longer writes it, so take the leftover with us
rm -rf /Users/Shared/nvfw 2>/dev/null || true
# the install's fallback job and the boot guard's counters (a removed driver has nothing to fall back to)
launchctl bootout system/com.nullmoth.lastgood 2>/dev/null || true
rm -f /Library/LaunchDaemons/com.nullmoth.lastgood.plist /Library/NullMoth/lastgood.sh || die "cannot remove the fallback job"
launchctl bootout system/com.nullmoth.bootguard 2>/dev/null || true
rm -f /Library/LaunchDaemons/com.nullmoth.bootguard.plist /Library/NullMoth/bootguard.sh || die "cannot remove the boot-guard job"
nvram -d 7C436110-AB2A-4BBB-A880-FE41995C9F82:nullmoth-nv-starts 2>/dev/null || true
nvram -d 7C436110-AB2A-4BBB-A880-FE41995C9F82:nullmoth-nv-ok 2>/dev/null || true
if [ "$REMOVE_KC" = 1 ]; then
  rm -f "$KC" "$KC.nullmoth-install-new" "$KC.nullmoth-update-new" "$KC.nullmoth-remove-new" || die "cannot remove the auxiliary collection"
elif [ "$CANDIDATE" = "$NEWKC" ]; then
  [ -s "$NEWKC" ] || cp -p "$RB/removal-candidate.kc" "$NEWKC" || die "cannot restore the removal collection from its copy"
  mv -f "$NEWKC" "$KC" || die "cannot publish the removal collection"
else
  cp -p "$CANDIDATE" "$KC" || die "cannot publish the verified backup collection"
fi
if [ -f "$KC" ]; then
  FINAL_INS=$(kmutil inspect -a x86_64 -A "$KC" 2>/dev/null) || die "cannot verify the published removal collection"
  printf '%s\n' "$FINAL_INS" | grep -q com.nullmoth && die "the kernel collection still lists the NVIDIA driver"
fi
REMOVING=0
rm -rf "$RB"
echo "Driver removed. Reboot now: sudo shutdown -r now"
